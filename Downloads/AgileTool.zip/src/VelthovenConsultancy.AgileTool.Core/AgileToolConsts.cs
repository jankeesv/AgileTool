﻿namespace VelthovenConsultancy.AgileTool
{
    public class AgileToolConsts
    {
        public const string LocalizationSourceName = "AgileTool";

        public const string ConnectionStringName = "Default";
    }
}