# bootstrap-theme-cosmo

> Bower repo for Bootswatch's Cosmo theme

## License

Copyright 2012-2014 Thomas Park
